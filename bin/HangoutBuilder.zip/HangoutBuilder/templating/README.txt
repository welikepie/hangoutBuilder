properties is final version.
copy propertiesTemplate and edit it.
Then run file.
???
success.